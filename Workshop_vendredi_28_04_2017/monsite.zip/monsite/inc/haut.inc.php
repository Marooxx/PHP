<!DOCTYPE html>
<html>
	<head>
		<title>Mon Site</title>
		<link rel="stylesheet" href="inc/css/style.css">
	</head>
	<body>
		<header>
			<div class="conteneur">
				<span>
					<a href="" title="Mon Site">MonSite.com</a>
				</span>
				<nav>
					<a href="inscription.php">Inscription</a>
					<a href="connexion.php">Connexion</a>
					<a href="boutique.php">Boutique</a>
					<a href="panier.php">Voir votre panier</a>
				</nav>
			</div>
		</header>
		<section>
			<div class="conteneur">