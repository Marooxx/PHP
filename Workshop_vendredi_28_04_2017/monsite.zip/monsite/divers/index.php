<?php
require_once("inc/haut.inc.php");
require_once("inc/bas.inc.php");
?>